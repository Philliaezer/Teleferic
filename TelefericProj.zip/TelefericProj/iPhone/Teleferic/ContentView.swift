//
//  ContentView.swift
//  Teleferic
//
//  Created by Usuário Convidado on 03/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            TabView {
                
                // ======== INICIO ========
                NavigationStack {
                    Text("oi")
                    .navigationTitle("Teleferic")
                }
                .tabItem {
                    Label("Inicio", systemImage: "dollarsign.circle.fill")
                }
            }
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
